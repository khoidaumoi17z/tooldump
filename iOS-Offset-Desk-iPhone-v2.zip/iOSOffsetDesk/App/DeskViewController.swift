import UIKit
import WebKit
import UniformTypeIdentifiers

// Weak proxy avoids a WKUserContentController -> controller retain cycle.
private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

final class DeskViewController: UIViewController, WKScriptMessageHandler,
                                WKNavigationDelegate, UIDocumentPickerDelegate {
    private var webView: WKWebView!
    private var importKind: String?
    private var importing = false
    private var exportURL: URL?
    private var allowedDirectory: URL?
    private var loadedBinaryURL: URL?
    private var dumping = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 12/255, green: 20/255, blue: 35/255, alpha: 1)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.add(WeakMessageHandler(self), name: "iosDesk")
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        guard let directory = Bundle.main.url(forResource: "Web", withExtension: nil),
              FileManager.default.fileExists(atPath: directory.appendingPathComponent("index.html").path) else {
            showError("Không tìm thấy giao diện Web trong bundle.")
            return
        }
        allowedDirectory = directory
        webView.loadFileURL(directory.appendingPathComponent("index.html"), allowingReadAccessTo: directory)
    }

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              let body = message.body as? [String: Any],
              let action = body["action"] as? String else { return }
        switch action {
        case "pick":
            guard !importing, !dumping, importKind == nil, presentedViewController == nil,
                  let kind = body["kind"] as? String,
                  kind == "binary" || kind == "dump" else { return }
            importKind = kind
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: false)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)
        case "export":
            guard !dumping else { return }
            guard let name = body["name"] as? String, let text = body["text"] as? String else { return }
            share(text: text, name: name)
        case "copy":
            guard let text = body["text"] as? String else { return }
            UIPasteboard.general.string = text
            notify("Đã copy mã vào clipboard.")
        case "dump":
            startDump(body)
        case "openURL":
            guard let value = body["url"] as? String, let url = URL(string: value),
                  url.scheme == "https", ["github.com", "ghidra.re"].contains(url.host ?? "") else { return }
            UIApplication.shared.open(url)
        default: break
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        importKind = nil
        notify("Đã hủy chọn file.")
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first, let kind = importKind else { importKind = nil; return }
        importKind = nil
        importing = true
        Task { @MainActor in
            defer { importing = false }
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var handle: FileHandle?
            var newSnapshot: URL?
            defer { try? handle?.close() }
            defer {
                if let snapshot = newSnapshot, snapshot != loadedBinaryURL {
                    try? FileManager.default.removeItem(at: snapshot)
                }
            }
            do {
                let resource = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                guard resource.isRegularFile == true, let size = resource.fileSize else {
                    throw DeskError.message("Hãy chọn một file, không chọn thư mục.")
                }
                let limit = kind == "binary" ? 512 * 1024 * 1024 : 100 * 1024 * 1024
                guard size <= limit else { throw DeskError.message("File vượt giới hạn \(limit / 1024 / 1024) MiB.") }
                var inputURL = url
                if kind == "binary" {
                    let snapshot = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".macho")
                    try FileManager.default.copyItem(at: url, to: snapshot)
                    newSnapshot = snapshot
                    inputURL = snapshot
                }
                try await call("begin", arguments: [kind, url.lastPathComponent, size])
                let file = try FileHandle(forReadingFrom: inputURL)
                handle = file
                // Chunk transfer avoids one very large base64 JavaScript command.
                while let chunk = try file.read(upToCount: 512 * 1024), !chunk.isEmpty {
                    try await call("append", arguments: [chunk.base64EncodedString()])
                }
                try await call("finish", arguments: [])
                if let snapshot = newSnapshot {
                    if let old = loadedBinaryURL { try? FileManager.default.removeItem(at: old) }
                    loadedBinaryURL = snapshot
                }
            } catch {
                try? await call("cancel", arguments: ["Không nhập được file: \(error.localizedDescription)"])
                showError(error.localizedDescription)
            }
        }
    }

    private func call(_ method: String, arguments: [Any]) async throws {
        let data = try JSONSerialization.data(withJSONObject: arguments, options: [.fragmentsAllowed])
        guard let json = String(data: data, encoding: .utf8) else { throw DeskError.message("Không mã hóa được dữ liệu.") }
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            webView.evaluateJavaScript("window.OffsetIOS.\(method)(...\(json));") { _, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: ()) }
            }
        }
    }

    private func notify(_ text: String) {
        Task { @MainActor in try? await call("notify", arguments: [text]) }
    }

    private func share(text: String, name: String) {
        guard presentedViewController == nil else { return }
        let filename = URL(fileURLWithPath: name).lastPathComponent
        guard !filename.isEmpty, filename != ".", filename != ".." else { return }
        do {
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let file = folder.appendingPathComponent(filename)
            try text.write(to: file, atomically: true, encoding: .utf8)
            presentFile(file)
        } catch { showError(error.localizedDescription) }
    }

    private func presentFile(_ file: URL) {
            guard presentedViewController == nil else { return }
            exportURL = file
            let activity = UIActivityViewController(activityItems: [file], applicationActivities: nil)
            if let popover = activity.popoverPresentationController {
                popover.sourceView = view
                popover.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 40, width: 1, height: 1)
            }
            activity.completionWithItemsHandler = { [weak self] _, completed, _, error in
                if let error { self?.showError(error.localizedDescription) }
                else if completed { self?.notify("Đã xuất file qua bảng chia sẻ.") }
                self?.exportURL = nil
                // Leave the temp file until a later launch; recipients may read asynchronously.
            }
            present(activity, animated: true)
    }

    private func startDump(_ body: [String: Any]) {
        guard !importing, !dumping, let input = loadedBinaryURL else {
            notify("Nạp Mach-O trước và chờ tác vụ hiện tại hoàn tất."); return
        }
        func number(_ key: String) -> UInt64? {
            guard let s = body[key] as? String else { return nil }
            return s.lowercased().hasPrefix("0x") ? UInt64(s.dropFirst(2), radix: 16) : UInt64(s)
        }
        guard let offset = number("offset"), let address = number("address"), let length = number("length"),
              let mode = body["mode"] as? Int, (0...2).contains(mode), length > 0,
              length <= (mode == 0 ? 512 : 64) * 1024 * 1024 else {
            notify("Vùng dump không hợp lệ hoặc quá lớn."); return
        }
        if mode == 2, body["encrypted"] as? Bool == true {
            notify("Vùng mã còn mã hóa: chỉ xuất BIN/HEX, không giải mã assembly."); return
        }
        dumping = true
        Task { @MainActor in
            defer { dumping = false }
            try? await call("setDumpBusy", arguments: [true])
            do {
                let ext = mode == 0 ? "bin" : mode == 1 ? "hex.txt" : "asm"
                let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let output = folder.appendingPathComponent("dump_" + String(address, radix: 16) + "." + ext)
                let inputPath = input.path, outputPath = output.path
                let result = await Task.detached(priority: .userInitiated) { () -> (Int32, UInt64, UInt64) in
                    var stats = DeskDumpStats()
                    let code = desk_dump_range(inputPath, outputPath, offset, address, length, Int32(mode), &stats)
                    return (code, stats.decoded, stats.unknown)
                }.value
                guard result.0 == 0 else {
                    throw DeskError.message(String(cString: desk_dump_error(result.0)))
                }
                let summary = mode == 2 ? "Đã dump: \(result.1) lệnh; \(result.2) mục không giải mã được." : "Đã xuất \(length) byte dữ liệu."
                try? await call("notify", arguments: [summary + " Chọn Lưu vào Tệp."])
                presentFile(output)
            } catch {
                notify("Dump thất bại: \(error.localizedDescription)")
                showError(error.localizedDescription)
            }
            try? await call("setDumpBusy", arguments: [false])
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL, let directory = allowedDirectory,
           url.standardizedFileURL.path.hasPrefix(directory.standardizedFileURL.path + "/") {
            decisionHandler(.allow)
        } else if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
            if navigationAction.navigationType == .linkActivated,
               url.scheme == "https", ["github.com", "ghidra.re"].contains(url.host ?? "") {
                UIApplication.shared.open(url)
            }
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        importing = false
        importKind = nil
        webView.reload()
        showError("iOS đã đóng tiến trình giao diện, có thể do thiếu bộ nhớ. Hãy thử file nhỏ hơn; dữ liệu phiên cũ không được lưu.")
    }

    private func showError(_ text: String) {
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: "iOS Offset Desk", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Đóng", style: .default))
        present(alert, animated: true)
    }
}

private enum DeskError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let value) = self { return value }; return nil }
}
