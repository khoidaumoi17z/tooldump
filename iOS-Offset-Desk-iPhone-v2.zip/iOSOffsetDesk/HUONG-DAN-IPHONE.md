# iOS Offset Desk v2 — sửa workflow và thêm dump ARM64

## Hai lỗi thấy trong repository ipaoffset

Đã đọc GitHub API của `khoidaumoi17z/ipaoffset`:

- Commit thất bại `594a65d155bb46e07b94a14f19d127c493a9ea7b` có dòng đầu là `ame: Build iOS Offset Desk IPA`, thiếu chữ `n`. GitHub không nhận khóa `ame`; run kết thúc trước khi tạo job build.
- Cây file trên nhánh main tại thời điểm kiểm tra có `.github/workflows/build-ipa.yml.`: dư dấu chấm sau `.yml`. File này không có đuôi `.yml`/`.yaml` đúng để được nhận là workflow.

Đây là lỗi ở cấu hình workflow. Chưa có log Xcode từ lần chạy đó để kết luận source Swift có build được hay không.

## Cập nhật trên GitHub

1. Upload nguyên file `iOS-Offset-Desk-iPhone-v2.zip` vào thư mục gốc repository. Không giải nén ZIP trước khi upload. Giữ nguyên tên.
2. Vào `.github/workflows/`, xóa file sai tên `build-ipa.yml.` hoặc đổi tên đúng thành `build-ipa.yml`.
3. Thay toàn bộ nội dung file workflow bằng nội dung của `build-ipa.yml` được cung cấp cùng bản v2. Cách ít nhầm nhất: upload trực tiếp file `build-ipa.yml` vào thư mục `.github/workflows/`.
4. Đường dẫn cuối cùng phải đúng: `.github/workflows/build-ipa.yml`. Dòng đầu phải là `name: Build iOS Offset Desk v2`.
5. Commit vào nhánh main. Workflow tự chạy khi ZIP/workflow thay đổi. Bạn cũng có thể vào **Actions → Build iOS Offset Desk v2 → Run workflow**.
6. Khi build thành công, tải artifact `iOS-Offset-Desk-v2-unsigned-IPA`, giải nén để lấy `iOS-Offset-Desk-v2-unsigned.ipa`.
7. IPA chưa ký; cần ký/provision và cài bằng phương thức phù hợp với iPhone của bạn.
8. Nếu bước Xcode lỗi, tải artifact `iOS-Offset-Desk-v2-build-log` hoặc mở step đỏ và lấy dòng lỗi. Bản v2 chủ động lưu `xcode-build.log` để chẩn đoán.

Bạn có thể giữ ZIP v1 trong repo; workflow v2 chỉ đọc ZIP v2.

## Dump ARM64 và dữ liệu

1. Mở app, chọn **Mở Mach-O iOS**, chọn executable hoặc thư viện của bản iOS.
2. Trong phần **Dump mã ARM64 và dữ liệu**, chọn section. Ví dụ vùng mã thường là `__TEXT,__text`.
3. **Bắt đầu trong section**: `0x0` nghĩa là đầu section. Đây không phải file offset toàn file.
4. **Số byte**: mặc định là kích thước section. Có thể nhập số thập phân hoặc `0xHEX`.
5. Chọn:

| Nút | Kết quả |
|---|---|
| Dump ARM64 .asm | Assembly có VA, byte gốc và mnemonic/operand do Capstone 5.0.3 giải mã |
| Dump HEX .txt | Byte dạng hex/ASCII kèm file offset và VA |
| Dump dữ liệu .bin | Byte gốc của vùng đã chọn, không sửa đổi |

6. Chờ tạo file, chọn **Lưu vào Tệp** trong bảng chia sẻ.

ASM/HEX tối đa 64 MiB đầu vào mỗi lần, BIN tối đa 512 MiB. Với section lớn, chia vùng bằng hai ô bắt đầu/số byte. Assembly yêu cầu VA chia hết cho 4. Mỗi lệnh không được Capstone nhận diện sẽ xuất `.word`; byte lẻ cuối vùng sẽ xuất `.byte`, không bỏ mất dữ liệu.

File còn `cryptid != 0` được xuất BIN/HEX nguyên trạng; nút ASM bị khóa để tránh trình bày byte mã hóa như mã máy có nghĩa. Section zero-fill không có byte trong file nên không được dump thành byte giả.

## Những chức năng tiếp tục giữ

- Đọc Mach-O ARM64/thin/FAT, liệt kê VA/RVA/file offset/slice offset.
- Nạp dump C và ghép theo nhãn địa chỉ.
- Xem hàm, lọc danh sách, xuất CSV/JSON.
- Sinh khung Dobby .mm theo chữ ký người dùng nhập, copy và lưu file.
- Toàn bộ `core.js` vẫn giống bản v1; bộ dump mới là phần bổ sung.

Dump ASM là giải mã lệnh, không phải decompile ra C. App không lấy bộ nhớ game đang chạy, không giải mã FairPlay, không tự xác định antiban. Vẫn cần file Mach-O đã có trong Tệp; không chọn IPA/ELF/APK nguyên gói.

## Build và phạm vi kiểm thử

- Mã C của bộ dump cùng Capstone đã được biên dịch và chạy trên Linux để kiểm tra ASM/HEX/BIN, opcode không nhận diện, byte cuối, ranh giới khối 64 KiB, file offset/VA và lỗi vùng đọc.
- Bridge/giao diện đã được kiểm thử DOM mô phỏng; giá trị CSV/offset và mã hook khớp bản trước với cùng dữ liệu mẫu.
- Workflow kiểm tra YAML và cú pháp các đoạn shell; source Capstone cần thiết được đóng gói sẵn, không tải thêm Capstone khi build.
- Chưa chạy Xcode/iOS Simulator hoặc iPhone trong phiên này; chưa có IPA build thành công để bàn giao. Không coi kiểm thử Linux/DOM là xác nhận runtime iOS.

Vì vẫn dùng cùng cơ chế đọc file, file lớn có thể vượt bộ nhớ thực tế của iPhone dù nằm trong giới hạn nhập. Giữ app ở foreground trong lúc dump. Báo cáo/phiên làm việc cần xuất trước khi đóng app.

## Thành phần và bản quyền

Capstone 5.0.3 (chỉ build ARM64) được kèm theo trong `Vendor/Capstone`. Các file nguồn được giữ nguyên, kèm `LICENSE.TXT`, `LICENSE_LLVM.TXT`, và thông tin nguồn. Bản app cũng chứa `ThirdPartyNotices.txt`.

Nguồn: https://www.capstone-engine.org/lang_c.html và https://github.com/capstone-engine/capstone/tree/5.0.3
